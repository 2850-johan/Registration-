public class User {
    // declaration des variables
    public String name;
    public String email;
    public String phone;
    public String adresse;
    public String password;

}
