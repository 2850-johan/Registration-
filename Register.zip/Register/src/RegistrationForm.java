import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.stream.Stream;

public class RegistrationForm extends JDialog {
    private JTextField tfName;
    private JTextField tfEmail;
    private JTextField tfPhone;
    private JTextField tfAdresse;
    private JPasswordField pfpassword;
    private JPasswordField pfconfirmpassword;
    private JButton btnregister;
    private JButton btncancel;
    private JPanel registerPanel;

    public RegistrationForm(JFrame parent)
    {
        super(parent);
        setTitle("Create a new account");
        setContentPane(registerPanel);
        setMaximumSize(new Dimension(450,474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        btnregister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
                
            }

        });
        btncancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        setVisible(true);
    }
    private void registerUser() {
        // Ici on recupere les valeurs entrées sur l'interface qu'on stocke dans les variables
        String name= tfName.getText();
        String email = tfEmail.getText();
        String phone = tfPhone.getText();
        String adresse = tfAdresse.getText();
        String password = String.valueOf(pfpassword.getPassword());
        String confirmPassword = String.valueOf(pfconfirmpassword.getPassword());

        if (Stream.of(name, email, phone, adresse, password).anyMatch(String::isEmpty))
        {
            JOptionPane.showConfirmDialog(this,"Please remplir tous les champs","Recommencez !",JOptionPane.ERROR_MESSAGE );
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Le mot de passe n'est pas identique!", "Try again", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
      user=addUserToDatabase(name,email,phone,adresse,password);
        if(user!=null)
        {
            dispose();
        }
        else {
            JOptionPane.showMessageDialog( this,"Enregistrement echoué!", "Try again",JOptionPane.ERROR_MESSAGE);

        }
    }
   public User user;
    private User addUserToDatabase(String name, String email, String phone, String adresse, String password)
    {
        try {
            String url = "jdbc:mysql://localhost:3306/etudiant";
            String user1 = "root";
            String passwd = "472580";

            // connexion à la BD
            Connection connection = DriverManager.getConnection(url, user1, passwd);
            System.out.println("Connexion effective !");

            Statement stmt = connection.createStatement();
            String sql = "INSERT INTO users (name,email,phone,adresse,password)" + "VALUES(?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,name);
            preparedStatement.setString(2,email);
            preparedStatement.setString(3,phone);
            preparedStatement.setString(4,adresse);
            preparedStatement.setString(5,password);

            // insert row into the table
             int addedRows = preparedStatement.executeUpdate();
             if (addedRows>0)
             {
                 user = new User();
                 user.name=name;
                 user.email=email;
                 user.phone=phone;
                 user.adresse=adresse;
                 user.password=password;
             }
             stmt.close();
             connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return user;
    }

        public static void main(String[] args)
        {
           RegistrationForm myForm = new RegistrationForm(null);
            User user =  myForm.user;
            if (user !=null)
            {
                System.out.println("Enregistré avec succes" + user.name);
            }
            else {
                System.out.println("Inscription annulée ");
            }

       }

}

